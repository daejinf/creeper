"""Optional local module bench."""
